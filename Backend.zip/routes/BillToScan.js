var express = require('express');
var router = express.Router();
const multer = require('multer'); // For handling multipart/form-data (file uploads)
const path = require('path');
var db = require("../config/db");

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './uploads/'); // Destination folder for uploaded files
    },
    filename: function (req, file, cb) {
        cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
    }
});

const upload = multer({ storage: storage });

const greenColor = '\x1b[32m'; // Green
const blueColor = '\x1b[34m'; // Blue
const redColor = '\x1b[31m'; // Red
const yellowColor = '\x1b[33m'; // Yellow
const purpleColor = '\x1b[35m'; // Purple
/* GET home page. */
router.get('/', function (req, res, next) {
    res.render('index', { title: 'Jalan' });
});


router.get('/master_data', async function (req, res, next) {
    console.log(blueColor, "=====================================================")
    console.log(" Accessing get./inven/masterdata")

    const searchTerm = req.query.searchTerm; // Extract the search term from the query parameters
    const category = req.query.category; // Extract the category from the query parameters


    let query = `SELECT 
    BT.BillTipe_Name,
    BL.*,
    DATE_FORMAT(BL.Bill_Date, '%Y-%m-%d') AS Bill_Date, -- Format Bill_Date as YYYY-MM-DD,
    BI.*
FROM 
    u1109947_Yorozuya.BillScanner_Log BL
JOIN 
    u1109947_Yorozuya.BillScanner_Item BI ON BL.Bill_ID = BI.Bill_ID 
JOIN 
    u1109947_Yorozuya.BillScanner_BillTipe BT ON BL.BillTipe_ID = BT.BillTipe_ID 
GROUP BY
BL.Bill_ID    
    `;

    // If a search term is provided, add a condition to filter the results
    if (searchTerm && searchTerm !== '') {
        query += ` AND ( BT.BillTipe_Name LIKE '%${searchTerm}%' OR BL.Bill_NamaToko LIKE '%${searchTerm}%' ) `; // Assuming you want to search in the `nama_produk` column
    }


    // If a category is provided, add a condition to filter the results
    if (category && category !== 'undefined') { // Check if category is defined and not 'undefined'
        query += ` AND BT.BillTipe_Name = '${category}'`; // Adjust the column name as per your database schema
    }

    try {
        const [rows, fields] = await
            db.query(query);
        res.json(rows);
        console.log(greenColor, "=====================================================")
        console.log(` Akses Get Inventory, Query :`)
        console.log(yellowColor, `Search   :`, searchTerm)
        console.log(` Category :`, category)
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server Error');
    }
});

router.post('/master_data', upload.single('photo'), async function (req, res, next) {
    console.log("Accessing POST /master_data");

    // Extract data from the request body
     const jsonData = req.body;
    console.log("Received JSON data:", jsonData);

    // Extract file information
    const file = req.file;
    if (!file) {
        return res.status(400).send('No file uploaded');
    }
    console.log("Received file:", file);

    let companyInfo, itemInfo, billInfo;

    // Iterate over the data array to extract the relevant information
    jsonData.forEach(entry => {
        if (entry['company-information']) {
            companyInfo = entry['company-information'];
        }
        if (entry['item-information']) {
            itemInfo = entry['item-information'];
        }
        if (entry['bill-information']) {
            billInfo = entry['bill-information'];
        }
    });

    console.log("companyInfo data:", companyInfo);
    console.log("itemInfo data:", itemInfo);
    console.log("billInfo data:", billInfo);

    if (!companyInfo || !itemInfo || !billInfo) {
        return res.status(400).send('Invalid data format');
    }

    // Build your insert queries here
    const billInsertQuery = `INSERT INTO u1109947_Yorozuya.BillScanner_Log (BillTipe_ID, Grand_Total, Bill_Date, Grand_Discount, Bill_NamaToko, Bill_CreatedDate, Bill_Remark, Image_Path) VALUES ?`;
    const itemInsertQuery = `INSERT INTO u1109947_Yorozuya.BillScanner_Item (Item_Name, Item_Price, Item_Discount, Item_Quantity, Bill_ID) VALUES ?`;

    const companyName = companyInfo[0]['company-name'];

    try {
        // Prepare bill values for insertion
        const totalDiskon = billInfo[0]["total-diskon"] ? parseFloat(billInfo[0]["total-diskon"].replace(',', '')) : 0;
        const createdDate = new Date().toISOString().slice(0, 19).replace('T', ' '); // Get current date in MySQL datetime format
        const billDate = new Date(billInfo[0]['bill-date']).toISOString().split('T')[0];
        const totalBillPrice = parseFloat(billInfo[0]['total-price'].replace(',', ''));
        const remarks = billInfo[0]["remarks"] ? billInfo[0]["remarks"] : "-";
        const imagePath = file.path;

        const billValues = [
            [billInfo[0]["bill-type"], totalBillPrice, billDate, totalDiskon, companyName, createdDate, remarks, imagePath]
        ];

        console.log("Prepared bill values:", billValues);

        // Insert into bill table and get the inserted Bill_ID
        const [result] = await db.query(billInsertQuery, [billValues]);
        console.log("Bill insert result:", result);

        const billId = result.insertId;
        console.log("Inserted Bill ID:", billId);

        // Prepare item values for insertion
        const itemValues = itemInfo.map(item => [item["item-name"], item["item-price"], item["item-discount"], item["item-quantity"], billId]);

        console.log("Prepared item values:", itemValues);

        // Insert into item table
        const itemResult = await db.query(itemInsertQuery, [itemValues]);
        console.log("Item insert result:", itemResult);

        res.status(200).send('Data inserted successfully');
        console.log("Data inserted successfully");
    } catch (err) {
        console.error("Error inserting data:", err);
        res.status(500).send('Server Error');
    }
});


module.exports = router;
